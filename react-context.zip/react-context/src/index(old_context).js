import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';


class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            num: 0
        }
    }

    static childContextTypes = {
        num: PropTypes.number,
        changeNum: PropTypes.func
    }
    getChildContext() {
        return {
            num: this.state.num,
            changeNum: (val) => {
                this.setState({ num: val })
            }
        }
    }

    render() {
        console.log(this.state.num)
        return (
            <div>
                父级组件{this.state.num}
                <hr />
                <Child />
            </div>
        );
    }
}

class Child extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    render() {
        return (
            <div>子级组件
                <Sunzi />
            </div>
        );
    }
}

class Sunzi extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    static contextTypes = {
        num: PropTypes.number,
        changeNum: PropTypes.func
    }
    render() {
        return (
            <div>
                <button onClick={() => { this.context.changeNum(10) }}>点击</button>
                孙子组件{this.context.num}
            </div>
        );
    }
}


ReactDOM.render(<App />, document.getElementById('root'))