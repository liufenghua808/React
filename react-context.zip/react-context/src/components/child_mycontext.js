import React, { Component } from 'react';
import MyContext from '../context';
let { Consumer } = MyContext;

class Child extends Component {
    constructor(props) {
        super(props);
        this.state = {
            num: 10
        }
    }

    static contextType = MyContext;

    add = () => {
        this.setState({
            num: this.state.num + 1
        })
    }
    componentDidMount() {
        let value = this.context;
        this.setState({ num: value.num })
    }
    render() {
        return (
            <div>
                <button onClick={this.add}>点击</button>
                <p>孙子组件{this.state.num}</p>
            </div>
        );
    }
}

export default Child;