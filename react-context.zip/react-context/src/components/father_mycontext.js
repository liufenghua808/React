import React, { Component } from 'react';
import Child from './child_mycontext';
class Father extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    render() {
        return (
            <div>
                父级组件
                <hr />
                <Child />
            </div>
        );
    }
}

export default Father;