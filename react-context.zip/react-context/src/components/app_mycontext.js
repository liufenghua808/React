import React, { Component } from 'react';
import MyContext from '../context';
import Father from './father_mycontext';
const { Provider } = MyContext;

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            num: 0
        }
    }

    render() {
        return (
            <Provider value={{ num: this.state.num}}>
                <p>爷爷组件{this.state.num}</p>
                <hr />
                <Father />
            </Provider>
        );
    }
}

export default App;