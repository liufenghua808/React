import React, { Component } from 'react';
const { Provider, Consumer } = React.createContext();
class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            num: 0
        }
    }

    changeNum = () => {
        this.setState((prev) => ({
            num: prev.num + 1
        }))
    }

    render() {
        return (
            <Provider value={{ num: this.state.num, changeNum: this.changeNum }}>
                <p>爷爷组件{this.state.num}</p>
                <hr />
                <Father />
            </Provider>
        );
    }
}


class Father extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    render() {
        return (
            <div>
                <p>父级组件</p>
                <Child />
            </div>
        );
    }
}


class Child extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    render() {
        let { num, changeNum } = this.props;
        return (
            <Consumer>{
                ({ num, changeNum }) => {
                    return (
                        <div>
                            <button onClick={changeNum}>点击</button>
                            <p>子级组件{num}</p>
                        </div>
                    )
                }
            }

            </Consumer>
        );
    }
}

export default App;