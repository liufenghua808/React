import React, { PureComponent } from 'react';
import ReactDOM from 'react-dom';
// import App from './components/app';
import App from './components/app_mycontext'
if (module.hot) {
    module.hot.accept();
}

ReactDOM.render(<App />, document.getElementById('root'))